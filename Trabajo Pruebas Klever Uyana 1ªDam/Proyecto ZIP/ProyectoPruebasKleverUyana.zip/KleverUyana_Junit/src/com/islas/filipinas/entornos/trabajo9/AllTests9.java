package com.islas.filipinas.entornos.trabajo9;
/**
 * En esta clase se define la clase Suite para las Pruebas en conjunto 
 * del ejecicio 9
 * La prueba 2 da error a propoccito
 * @author klever
 *
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
//para poder hacer el Suit he tenido que pasar
//las pruebas que queria poner a Junit4
@RunWith(Suite.class)
@SuiteClasses({ 
	Prueba1Ejercicio9Test.class,//correcto
	//Prueba2Ejercicio9Test.class,//fallo a propocito
	Prueba6Ejercicio9.class//correcto
	
	})
public class AllTests9 {

}
