package com.islas.filipinas.entornos.trabajo9;

import com.islas.filipinas.entornos.trabajos.DiezException;
/**
 * Classe que contiene el metodo de suma de numeros negativos
 * @author klever Uyana Barahona
 *
 */
public class Ejercicio9MyMath {
	/** Comenzamos lo que debe ralizar el modulo.
	 * En este caso nos piden M�todo que calcule la suma de un conjunto de
	 *  n�meros negativos almacenados en memoria.
	 *  Deber� de dar excepci�n si alg�n n�mero es positivo.
	 * @throws NueveException */
    public static double PI = Math.PI;
    /**
     * Metodo suma de los numero negativos
     * @param numeros - dados por el usuario
     * @return la suma de los numero negativos
     * @throws NueveException
     */
    //Para este Proceso se ha utilizado Array para Guardar la imformacion.
	public static int sumaArrayNegativos(int[] numeros) throws NueveException {
		// TODO Auto-generated method stub
		 int s=0;
		for(int i=0; i< numeros.length;i++) {
			if(numeros[i]>0)
				throw new NueveException("No se pueden numeros positivos.");
			else
			s=s+numeros[i];
		}
		return s;
	}
}
