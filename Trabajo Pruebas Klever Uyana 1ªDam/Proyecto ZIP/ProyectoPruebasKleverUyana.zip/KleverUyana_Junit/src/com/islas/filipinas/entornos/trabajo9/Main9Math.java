package com.islas.filipinas.entornos.trabajo9;
/**
 * Clase prinsipal del sistema ejercicio 9
 * @author Klever
 *
 */
public class Main9Math {
	/**
	 * Este es el metodo principal del ejercicio 9
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Introduce numeros negativos para sumarlos");
		System.out.println("No introduzcas numeros positivos porfavor");
		int[] numeros = {-1,-2,-3,-4,-5,6};
		
		int s; 
		try {
			s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
			System.out.println("La Suma es"+ s);
		} catch (NueveException e) {
		System.out.println(e.getMessage()+" Que te no se puede����");
		}
		
	}

}
