package com.islas.filipinas.entornos.trabajo9;
/**
 * En esta clase se define la clase Exception del ejecicio 9
 * @author klever
 *
 */
public class NueveException extends Exception {
	 public NueveException(String m) {
		 super(m);
	 }
}
