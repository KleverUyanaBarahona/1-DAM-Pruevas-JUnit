package com.islas.filipinas.entornos.trabajo9;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class Prueba1Ejercicio9Test {
	//En esta prueba esta todo correcto por lo tanto no deberia dar error
		@Test
		public void test() throws NueveException {
			int[] numeros = {-1,-2,-3,-4,-5}; //todos son negativos
			int s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
			assertEquals(-15,s);
		}
}
