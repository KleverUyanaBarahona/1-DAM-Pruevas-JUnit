package com.islas.filipinas.entornos.trabajo9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba2Ejercicio9 {
//Puse un numero positivo por lo tanto tiene que darme error.
	@Test
	public void test() throws NueveException {
		int[] numeros = {-1,-2,-3,4,-5}; // el numero 4 me da error al ser positivo
		int s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
		assertEquals(-15,s);
	}

}
