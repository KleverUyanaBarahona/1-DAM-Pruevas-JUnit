package com.islas.filipinas.entornos.trabajo9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba3Ejercicio9 {
// al poner expected=NueveException.class, la prueba deberia dar positiva.
	//al parecer no lo detecta por que lo estoy haciendo con Junit5 y el expected en del Junit4
	//probare haciendolo en el Junit4 pero no se si puede funcionar
/*	@Test(expected=NueveException.class)
	public void test() throws NueveException {
		int[] numeros = {-1,-2,-3,4,-5}; // el numero 4 me da error al ser positivo
		int s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
		
	}*/
}
