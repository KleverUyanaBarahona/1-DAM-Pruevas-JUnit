package com.islas.filipinas.entornos.trabajo9;

import static org.junit.Assert.*;

import org.junit.Test;

class Prueba4Ejercicio9 {
	// Lo he echo en Junit4 y al parecer si lo detecta pero al darle run no me va
	// desconosco el porque
		@Test(expected=NueveException.class)
		public void test() throws NueveException {
			int[] numeros = {-1,-2,-3,4,-5}; // el numero 4 me da error al ser positivo
			int s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
		}
		//he estado buscando en foros y al paracer tengo que cambier el tipo de run 
		//Run Configuration
}
