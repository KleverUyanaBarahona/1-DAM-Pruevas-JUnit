package com.islas.filipinas.entornos.trabajo9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba5Ejercicio9 {
// he intentado hacerlo con el Junit 5 las Exception pero no he podido.
/*	@Test
	void testNueveException() {
	Thowable exception = assetThrows(NueveException.class,() ->{
	throw new NueveExpection("dhdu");
	}); */
	

}
