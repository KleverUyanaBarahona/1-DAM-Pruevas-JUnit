package com.islas.filipinas.entornos.trabajo9;

import static org.junit.Assert.*;

import org.junit.Test;

public class Prueba6Ejercicio9 {
//porfin he conseguido que me funcionara la prueba Exception.
	@Test(expected=NueveException.class)
	public void test() throws NueveException {
		int[] numeros = {-1,-2,-3,4,-5}; // el numero 4 me da error al ser positivo
		int s = Ejercicio9MyMath.sumaArrayNegativos(numeros);
	}
// al parecer tenia que dejar la RUN del JUpeter y solo crear otra prueba con Junit 4 
	//con los mismo parametros de la prueba original
}
