package com.islas.filipinas.entornos.trabajos;
/**
 * En esta clase se define la clase Suite para las Pruebas en conjunto 
 * del ejecicio 10
 * la prueba  tiene error adrede
 * @author klever
 *
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ 
	Prueba1Ejercicio10Test.class,//correcto
	//Prueba2Ejercicio10Test.class,//Da Error Adrede
	Prueba3Ejercicio10Test.class,//correcto
	Prueba4Ejercicio10Test.class,//correcto
	Prueba5Ejercicio10Test.class,//correcto
	Prueba6Ejercicio10.class//correcto
	})
public class AllTests10 {

}
