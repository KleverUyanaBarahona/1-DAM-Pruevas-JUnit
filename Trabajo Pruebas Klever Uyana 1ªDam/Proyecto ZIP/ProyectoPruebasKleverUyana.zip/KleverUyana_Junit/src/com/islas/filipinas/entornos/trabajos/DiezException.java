package com.islas.filipinas.entornos.trabajos;
/**
 * En esta clase se define la clase Exception del ejecicio 10
 * @author klever
 *
 */
public class DiezException extends Exception {
 public DiezException(String m) {
	 super(m);
 }
}
