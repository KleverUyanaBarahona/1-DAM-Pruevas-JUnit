package com.islas.filipinas.entornos.trabajos;
/**
 * ESta clase permite definir el metodo esPrimo
 * @author klever
 *
 */
public class Ejercicio10MyMath {
	/**
	 * Comenzamos lo que debe ralizar el modulo.
	 * En este caso nos piden un m�todo que calcule el n�mero primo
	 *  n. Debe devolver excepci�n si se le pide un n > 10
	 * @throws DiezException 
	 * @param n - valor ingresado por el usuario */
	
        public static boolean esPrimo(int n) throws DiezException {
		// TODO Auto-generated method stub
        	int aux;
        	if(n>10) {
        		//creamo una Exception para no que se habia requerido
        	throw new DiezException("No se admiten numeros menores de 10");	
        	}
        	else {
		//Esta es la parte de las instruciones del proceso,
        //esta parte se vera en profundidad en el PDF.
        		for (int cont=2;cont<n;cont++) {
        	aux=n%cont;
            if(aux==0)
                return false;    //respuesta del subproceso
        }
        return true;     //respuesta del subproceso
    }
    }
	}
//Para ver el resultado del Metodo voy a un m�todo main que lo llamare Main10Math(Clase)
