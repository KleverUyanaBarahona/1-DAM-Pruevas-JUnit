package com.islas.filipinas.entornos.trabajos;
import java.util.Scanner;
/**
 * Clase prinsipal del sistema ejercicio 10
 * @author Klever
 *
 */
public class Main10Math {
/**
 * Este es el metodo principal del ejercicio 10
 * @param args
 */
	public static void main(String[] args) {
		Ejercicio10MyMath algoritmoPrimos = new Ejercicio10MyMath();
		/* En esta parte llamamos al metodo que esta en la clase Ejercicio10MyMath
		 * En esta clase he definido el metodo main para hacer una prueba 
		 * En esta prueva lo realizamos entre el numero 1 al 12
		 * Para devolvernos si es primo o no lo es*/
	        int n = 0;
	        for (int i= 1; i<12; i++) {
	            n = i;
	            //Tras capturar la Exception con throw lo probamos con try y catch.
	            try {
					if (algoritmoPrimos.esPrimo(n) == true) {
						//Impresion en pantalla
					    System.out.println("El n�mero " + n + " es primo");
					}
					else {
					    System.out.println("El n�mero " + n + " no es primo");
					}
				} catch (DiezException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage()+" que no se puede!!!!"); //Da la respuesta de la Exception.
				}
	        }
	    }
	}
