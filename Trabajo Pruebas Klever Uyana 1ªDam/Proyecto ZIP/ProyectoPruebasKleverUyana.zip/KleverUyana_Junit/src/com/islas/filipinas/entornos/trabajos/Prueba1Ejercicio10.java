package com.islas.filipinas.entornos.trabajos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class Prueba1Ejercicio10 {
 //Con esto se marca que es una prueba se genera automaticamente lo dejare para dejarlo de muestra  
	/*@Test
	void test() {
		fail("Not yet implemented");  ---fail falla automaticamente---- 
	}*/
	@Before
	public void before() {
		System.out.println("Se va a ejetutar la prueba");
	//tambien hay marcas como @Before y After en esta ocacion solo las nombrare
		// no influiran en el tes o prueba
	}
	@After
	public void After() {
		System.out.println("La prueba ya a sido ejecutada");
	}
	
	@Test
	public void test() throws DiezException {
	int n = 9	;
	boolean resultado = Ejercicio10MyMath.esPrimo(n);
	}
	
//en esta prueba se comprueba si las respuestas de tipo Bit con iguales.
	
}
