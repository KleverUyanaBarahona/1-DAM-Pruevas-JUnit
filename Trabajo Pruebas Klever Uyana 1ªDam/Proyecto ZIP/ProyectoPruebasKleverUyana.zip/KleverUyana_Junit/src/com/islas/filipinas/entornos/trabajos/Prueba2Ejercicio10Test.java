package com.islas.filipinas.entornos.trabajos;

import static org.junit.Assert.*;

import org.junit.Test;

public class Prueba2Ejercicio10Test {
	/* en esta prueba voy a provocar que la prueba falle
	 * para ello voy a poner un valor superior a 10
	 * esto se debe a la Exception*/
		@Test
		public void test() throws DiezException {
		int n = 11	;
		boolean resultado = Ejercicio10MyMath.esPrimo(n);
		}
	}