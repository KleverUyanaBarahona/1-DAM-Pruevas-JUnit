package com.islas.filipinas.entornos.trabajos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba3Ejercicio10 {
	/* en esta prueba voy a hacerla con un numero negativo superior a -10
	 * en esta prueba se espera no fallar*/
		@Test
		public void test() throws DiezException {
		int n = -9	;
		boolean resultado = Ejercicio10MyMath.esPrimo(n);
		}

}
