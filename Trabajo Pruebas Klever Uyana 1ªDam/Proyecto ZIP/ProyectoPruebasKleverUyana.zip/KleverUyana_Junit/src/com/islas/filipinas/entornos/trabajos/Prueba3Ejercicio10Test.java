package com.islas.filipinas.entornos.trabajos;

import static org.junit.Assert.*;

import org.junit.Test;

public class Prueba3Ejercicio10Test {
	/* en esta prueba voy a hacerla con un numero negativo superior a -10
	 * en esta prueba se espera no fallar*/
		@Test
		public void test() throws DiezException {
		int n = -11	;
		boolean resultado = Ejercicio10MyMath.esPrimo(n);
		}

}

