package com.islas.filipinas.entornos.trabajos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba4Ejercicio10 {

	@Test
	public void testEjercicio10MyMath() throws DiezException {
		boolean ans = true; // lo que se espera
		boolean val;
		int n = 7; // 7 es numero Primo
		val = Ejercicio10MyMath.esPrimo(n);
		assertEquals(ans,val); //La comparacion
	}
	
}
