package com.islas.filipinas.entornos.trabajos;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class Prueba4Ejercicio10Test {

	@Test
	public void testEjercicio10MyMath() throws DiezException {
		boolean ans = true; // lo que se espera
		boolean val;
		int n = 7; // 7 es numero Primo
		val = Ejercicio10MyMath.esPrimo(n);
		assertEquals(ans,val); //La comparacion
	}
	
}
