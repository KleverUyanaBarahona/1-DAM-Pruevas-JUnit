package com.islas.filipinas.entornos.trabajos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Prueba5Ejercicio10 {
//correcto
	@Test
	public void testEjercicio10MyMath() throws DiezException {
		boolean ans = false; // lo que se espera
		boolean val;
		int n = 6; // 6 no es numero Primo
		val = Ejercicio10MyMath.esPrimo(n); //false=false
		assertEquals(ans,val); //La comparacion
	}
	
}
