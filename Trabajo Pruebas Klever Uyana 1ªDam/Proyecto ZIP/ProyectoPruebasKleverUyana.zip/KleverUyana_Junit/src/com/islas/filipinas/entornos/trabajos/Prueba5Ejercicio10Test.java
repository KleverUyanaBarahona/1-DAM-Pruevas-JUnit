package com.islas.filipinas.entornos.trabajos;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class Prueba5Ejercicio10Test {
	//correcto
		@Test
		public void testEjercicio10MyMath() throws DiezException {
			boolean ans = false; // lo que se espera
			boolean val;
			int n = 6; // 6 no es numero Primo
			val = Ejercicio10MyMath.esPrimo(n); //false=false
			assertEquals(ans,val); //La comparacion
		}
		
	}