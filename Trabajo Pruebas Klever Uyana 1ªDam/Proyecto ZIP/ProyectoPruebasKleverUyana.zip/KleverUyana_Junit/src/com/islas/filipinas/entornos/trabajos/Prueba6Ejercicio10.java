package com.islas.filipinas.entornos.trabajos;

import static org.junit.Assert.*;

import org.junit.Test;

public class Prueba6Ejercicio10 {

	@Test(expected=DiezException.class)
	public void test() throws DiezException{
		boolean val;
		int n = 12; 
		val = Ejercicio10MyMath.esPrimo(n);
		}

}
